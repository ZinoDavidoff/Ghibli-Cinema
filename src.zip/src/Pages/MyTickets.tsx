import { Button } from '@chakra-ui/react';
import React from 'react'

const MyTickets = () => {
  return (
    <Button width={100}>My Tickets</Button>
  )
}

export default MyTickets;

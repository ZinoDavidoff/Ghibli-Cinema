import Layout from "./Components/Layout";

const App = () => {
  return <Layout />;
};

export default App;
